import { startServer, app } from "./ApolloExpress";


//TODO Export Config in one Place
export { startServer, app };
